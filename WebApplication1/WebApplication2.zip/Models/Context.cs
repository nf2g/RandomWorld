﻿using System.Data.Entity;

namespace WebApplication1.Models
{
    public class Context : DbContext
    {
        public DbSet<WordSet> WordSets { get; set; }
    }

    /*//для обнуления базы данных
    public class MyContextInitializer : DropCreateDatabaseAlways<Context>//пересоздает базу данных
    {

    }*/
}